from package import add, subtract, multiply, divide, create_pdf

print(add(5, 3))
print(subtract(10, 4))
print(multiply(6, 7))
print(divide(20, 5))
create_pdf("output.pdf", "Hello, this is a sample PDF generated using FPDF in Python.")
